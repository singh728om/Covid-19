Contains the respective assets(images, styles, scripts).
